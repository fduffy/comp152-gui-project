#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_encryptButton_clicked()
{
    setKey();
    setTargetFile();
    setDestFile();
}

void MainWindow::on_decryptButton_clicked()
{

}

void MainWindow::setTargetFile()
{
   targetFile = ui->targetFileLine->text();
}

void MainWindow::setDestFile()
{
    destFile = ui->destFileLine->text();
}

void MainWindow::setKey()
{
    key = ui->keyLine->text().toInt();
}

void MainWindow::printVals()
{
    qDebug() << key;
    qDebug() << targetFile;
    qDebug() << destFile;
}

void MainWindow::on_testButton_clicked()
{
    printVals();
}
