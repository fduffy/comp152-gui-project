#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void setTargetFile();
    void setDestFile();
    void setKey();
    void printVals();


private slots:
    void on_encryptButton_clicked();

    void on_decryptButton_clicked();

    void on_testButton_clicked();

private:
    Ui::MainWindow *ui;
    QString targetFile;
    QString destFile;
    int key;

};

#endif // MAINWINDOW_H
